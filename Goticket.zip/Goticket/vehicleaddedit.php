<?php
	require "config.php";
	
	$bus_number=$_GET['bnum1'];
	$bus_driver=$_GET['driv1'];
	$bus_rid=$_GET['rid1'];
	$bus_type=$_GET['type1'];
	$bus_charge=$_GET['charge1'];

	$query ="SELECT Route_id,RName FROM route";
    $result = $conn->query($query);
    if($result->num_rows> 0){
    $options= mysqli_fetch_all($result,MYSQLI_ASSOC);
    }
	
?>
<!DOCTYPE html>
<html lang="en" lang="en>
<head>
    
    <title> Vehicle </title>
    <script type="text/javascript" src="javascript.js"></script>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>  
    <div class="sidebar" style="height:100%;">
        <div class="logo-details">
            <img src="image\bus.png">
            
        </div>
    <ul class="nav-links">
        <li>
            <a href="dashboard.php" >
            <img src="images/icons8-dashboard-48.png">
            <span class="links_name"> &emsp;Dashboard</span>
            </a>
        </li>
        <li>
            <a href="Createroute.php" >
                <img src="images/icons8-route-50.png">
            <span class="links_name"> &emsp;Create Route</span>
            </a>
        </li>
        <li>
            <a href="Editroute.php" >
                <img src="images/icons8-modify-58.png">
            <span class="links_name"> &emsp;Edit Route</span>
            </a>
        </li>
        <li>
            <a href="vehicle.php" class="active">
                <img src="images/icons8-bus-station-50.png">
            <span class="links_name"> &emsp;Vehicle</span>
            </a>
        </li>
        <li>
            <a href="adminpayment.php">
                <img src="images/icons8-wallet-50.png">
            <span class="links_name"> &emsp;Payment</span>
            </a>
        </li>
        <li>
            <a href="adminfeedback.php">
                <img src="images/icons8-online-support-50.png">
            <span class="links_name"> &emsp;Feedback</span>
            </a>
        </li>
       
        <li class="log_out">
            <a href="index.php">
                <img src="images/icons8-log-out-50.png">
            <span class="links_name"> &emsp;Log out</span>
            </a>
        </li>
    </ul>
    </div>
    <section class="home-section">
        <nav>
            <div class="sidebar-button">
                <span class="dashboard">&emsp;Vehicle</span>
            </div>
            <div class="search-box">
                <input type="text" placeholder="Search..." />
                
            </div>
            <div class="profile-details">
                <img src="images/admin.jpg" alt="" />
                <span class="admin_name">SURIYA</span>
            </div>
        </nav>
        <div class="Create-route">
            <br>
            <form class="form" method="POST" action="submitUpdateBus.php">
            <div class="input_container">

            <label class="input_label" >Bus Number : <?php echo$bus_number?></label>
	<input class="input_field" type="hidden" value="<?php echo$bus_number?>" name="Bus_num"  readonly >
	
	<label class="input_label" >Driver's Name</label>
	<input class="input_field" type="text" value=" <?php echo$bus_driver?>" name="Driver_name">
	
	<label class="input_label">RouteID</label>
	<select class="input_field" name="RID">
                <option>Select Route ID </option>
               <?php 
               foreach ($options as $option) {
               ?>
                 <option <?php if ( $option['Route_id'] == $bus_rid) { echo "selected";}?> ><?php echo $option['Route_id']."  ".$option['RName'];?> </option>
                 <?php 
                 }
                ?>
				</select>

	
             <label style="padding-left: 49%;" class="input_label" for="ac" >A/C</label>
             <input type="radio" id="ac"
             name="type"
             value="A/C" <?php if ($bus_type == "A/C") { echo "checked";}?> required>
             <label style="padding-left: 48%;" class="input_label" for="noac">NON-A/C</label>
             <input type="radio" id="noac" name="type" value="NON A/C" <?php if ($bus_type == "NON A/C"){ echo "checked";}?> >
             

	<label class="input_label">Charge :</label>
	<input class="input_field" type="text" value=" <?php echo$bus_charge?>" name="Bus_charge">
	
	
	
	<button type="submit" name="btnSubmit" > Update</button>
				</form>


            </div>
    </section>
</body>
<footer>
    <div class="row primary">
        <div class="column about">
            <h3>ChocoBois Developer</h3>
            <p>
                Gotickets is developled to make your Jornerey bookings do easier through our website
            </p>
            <div class="social">
                <i class="fa-brands fa-facebook-square"></i>
                <i class="fa-brands fa-instagram-square"></i>
                <i class="fa-brands fa-twitter-square"></i>
                <i class="fa-brands fa-youtube-square"></i>
                <i class="fa-brands fa-whatsapp-square"></i>
            </div>
        </div>
        <div class="column links">
            <h3>Follow Us</h3>
            <ul>
                <li>
                    <a href="#faq">facebook</a>
                </li>
                <li>
                    <a href="#cookies-policy">twitter</a>
                </li>
                <li>
                    <a href="#terms-of-services">Instagram</a>
                </li>
                <li>
                    <a href="#support">Whatsapp</a>
                </li>
            </ul>
        </div>
        <div class="column links">
            <h3>About Us</h3>
            <ul>
                <li>
                    <a href="#faq">F.A.Q</a>
                </li>
                <li>
                    <a href="#cookies-policy">Cookies Policy</a>
                </li>
                <li>
                    <a href="#terms-of-services">Terms Of Service</a>
                </li>
                <li>
                    <a href="#support">Support</a>
                </li>
            </ul>
        </div>
        <div class="column subscribe">
        <h3>Newsletter</h3>
            <div>
                <input type="email" placeholder="Your email id here" />
                <button>Subscribe</button>
            </div>
        </div>
    </div>
        <div class="row copyright">
        <p>Copyright &copy; 2023 SLIIT Developer</p>
        </div>
    </footer>
</html>
