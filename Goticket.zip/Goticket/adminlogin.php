
<html>
    <head>
        <title>Admin Login</title>
        <link rel="stylesheet" href="styles/Login.css">
        <script type="text/javascript" src="script.js"></script>
    </head>
    
    <body  >
    
       
        <div id="header"><center><br><a href="index.php">Home</a>
            &nbsp;&nbsp;&nbsp;&nbsp; <a href="whatsnew.html">What's new</a>
            &nbsp;&nbsp;&nbsp;&nbsp; <a href="Registration.html">Contact us</a>
            &nbsp;&nbsp;&nbsp;&nbsp; <a href="Registration.php">Sign Up</a>
            &nbsp;&nbsp;&nbsp;&nbsp; <a href="Registration.html">About us</a></center>
           
            <br>
        </div>
        <div   class="leftlayout"></div>
       <div class="rightlayout"><center><h1 style="font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;">GoTickets.lk</h1><br><br><br><br>
        <form class="form" >
            <p class="form-title">Sign in to your account</p>
             <div class="input-container">
               <input type="username" placeholder="Enter username" id="username" name="username"required>
               <span>
               </span>
           </div>
           <div class="input-container">
               <input type="password" placeholder="Enter password" id="password" name="password" required>
             </div>
              <button type="Submit" class="submit"  onclick="login()" >Sign in
           </button>
     
           
        </form></center>
    </div>
    <footer>
        <div class="row primary">
          <div class="column about">
            <h3>ChocoBois Developer</h3>
            <p>
              Gotickets is developled to make your Jornerey bookings do easier through our website

            </p>
                      <div class="social">
                        <i class="fa-brands fa-facebook-square"></i>
                        <i class="fa-brands fa-instagram-square"></i>
                        <i class="fa-brands fa-twitter-square"></i>
            <i class="fa-brands fa-youtube-square"></i>
              <i class="fa-brands fa-whatsapp-square"></i>
                      </div>
          </div>
          <div class="column links">
            <h3>Follow Us</h3>
            <ul>
              <li>
                <a href="#faq">facebook</a>
              </li>
              <li>
                <a href="#cookies-policy">twitter</a>
              </li>
              <li>
                <a href="#terms-of-services">Instagram</a>
              </li>
              <li>
                <a href="#support">Whatsapp</a>
              </li>
  
            </ul>
          </div>
            <div class="column links">
              <h3>About Us</h3>
              <ul>
                <li>
                  <a href="#faq">F.A.Q</a>
                </li>
                <li>
                  <a href="#cookies-policy">Cookies Policy</a>
                </li>
                <li>
                  <a href="#terms-of-services">Terms Of Service</a>
                </li>
                <li>
                  <a href="#support">Support</a>
                </li>
                <li>
                  <a href="adminlogin.php">login as admin</a>
                </li>
  
              </ul>
            </div>
          <div class="column subscribe">
            <h3>Newsletter</h3>
            <div>
              <input type="email" placeholder="Your email id here" />
              <button>Subscribe</button>
             
            </div>
            
  
          </div>
         
        </div>
        <div class="row copyright">
            <p>Copyright &copy; 2023 SLIIT Developer</p>
          </div>
       
      </footer>
    </body>
</html>





</body>



</html>